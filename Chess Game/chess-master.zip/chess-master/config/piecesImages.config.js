
export const piecesImages = {
    'white_pawn': './img/WhitePawn.png',
    'white_rook': './img/WhiteRook.png',
    'white_knight': './img/WhiteKnight.png',
    'white_bishop': './img/WhiteBishop.png',
    'white_king': './img/WhiteKing.png',
    'white_queen': './img/WhiteQueen.png',
    'black_pawn': './img/BlackPawn.png',
    'black_rook': './img/BlackRook.png',
    'black_knight': './img/BlackKnight.png',
    'black_bishop': './img/BlackBishop.png',
    'black_king': './img/BlackKing.png',
    'black_queen': './img/BlackQueen.png',
}
